const { db } = require('./connection');

// Tabel dibuat dengan IF NOT EXISTS supaya aman dijalankan tiap start.
// Semua tabel per-guild: primary key selalu mengandung guildId.
function createTables() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      userId TEXT,
      guildId TEXT,
      balance INTEGER DEFAULT 0,
      bank INTEGER DEFAULT 0,
      lastDaily TEXT,
      streak INTEGER DEFAULT 0,
      PRIMARY KEY (userId, guildId)
    );

    CREATE TABLE IF NOT EXISTS points (
      userId TEXT,
      guildId TEXT,
      points INTEGER DEFAULT 0,
      pendingWords INTEGER DEFAULT 0,
      xp INTEGER DEFAULT 0,
      level INTEGER DEFAULT 1,
      PRIMARY KEY (userId, guildId)
    );

    CREATE TABLE IF NOT EXISTS seasons (
      guildId TEXT NOT NULL,
      seasonNumber INTEGER NOT NULL,
      archivedAt INTEGER NOT NULL,
      actorId TEXT NOT NULL,
      weeklyPeriod TEXT NOT NULL,
      userCount INTEGER NOT NULL,
      PRIMARY KEY (guildId, seasonNumber)
    );

    CREATE TABLE IF NOT EXISTS season_stats (
      guildId TEXT NOT NULL,
      seasonNumber INTEGER NOT NULL,
      userId TEXT NOT NULL,
      balance INTEGER NOT NULL DEFAULT 0,
      bank INTEGER NOT NULL DEFAULT 0,
      points INTEGER NOT NULL DEFAULT 0,
      voice_seconds INTEGER NOT NULL DEFAULT 0,
      weeklyPoints INTEGER NOT NULL DEFAULT 0,
      weeklyRows TEXT NOT NULL DEFAULT '[]',
      PRIMARY KEY (guildId, seasonNumber, userId),
      FOREIGN KEY (guildId, seasonNumber) REFERENCES seasons (guildId, seasonNumber)
    );

    CREATE TABLE IF NOT EXISTS shop_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT UNIQUE,
      price INTEGER NOT NULL,
      description TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS user_items (
      userId TEXT,
      guildId TEXT,
      itemId INTEGER,
      quantity INTEGER DEFAULT 1,
      PRIMARY KEY (userId, guildId, itemId)
    );

    CREATE TABLE IF NOT EXISTS quests (
      userId TEXT,
      guildId TEXT,
      period TEXT,
      questId TEXT,
      target INTEGER NOT NULL,
      reward INTEGER NOT NULL DEFAULT 0,
      progress INTEGER DEFAULT 0,
      claimed INTEGER DEFAULT 0,
      lockedMultiplier REAL DEFAULT 1,
      PRIMARY KEY (userId, guildId, period, questId)
    );

    -- Snapshot akumulasi poin per periode (kunci pekan ISO dari lib/quests).
    -- Baris pekan lama sengaja dipertahankan sebagai riwayat.
    CREATE TABLE IF NOT EXISTS weekly_points (
      userId TEXT,
      guildId TEXT,
      period TEXT,
      points INTEGER DEFAULT 0,
      PRIMARY KEY (userId, guildId, period)
    );

    -- Buff aktif dari item. Satu baris per pemakaian; buff dengan key sama
    -- tidak dijumlahkan, yang dipakai pengali terbesar (lib/buffs.js).
    -- userId '*' = buff milik seluruh member guild.
    CREATE TABLE IF NOT EXISTS user_buffs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT,
      guildId TEXT,
      key TEXT NOT NULL,
      value REAL NOT NULL DEFAULT 1,
      expiresAt INTEGER,
      charges INTEGER
    );

    -- Cerminan sesi voice yang sedang berjalan (write-through dari memori).
    -- Kalau bot mati di tengah sesi, waktu mulai bisa dilanjutkan saat boot.
    CREATE TABLE IF NOT EXISTS voice_sessions (
      userId TEXT,
      guildId TEXT,
      joinedAt INTEGER NOT NULL,
      lastGrant INTEGER NOT NULL,
      eligible INTEGER DEFAULT 0,
      PRIMARY KEY (userId, guildId)
    );

    -- Mini boss yang pernah spawn. Baris 'active' dipakai untuk melanjutkan
    -- pertarungan setelah bot restart; baris lama disimpan sebagai riwayat.
    -- Kolom slot = kunci jadwal spawn (YYYY-MM-DDTHH waktu lokal event) supaya satu
    -- jadwal tidak pernah menghasilkan dua boss.
    CREATE TABLE IF NOT EXISTS boss_spawns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guildId TEXT NOT NULL,
      channelId TEXT NOT NULL,
      messageId TEXT,
      bossKey TEXT NOT NULL,
      maxHp INTEGER NOT NULL,
      hp INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      slot TEXT,
      spawnedAt INTEGER NOT NULL,
      endsAt INTEGER NOT NULL,
      endedAt INTEGER,
      lastHitUserId TEXT
    );

    -- Kontribusi damage per user pada satu boss. Kolom lastAttackAt sekaligus
    -- menjadi penyimpan cooldown tombol serang (tahan restart).
    CREATE TABLE IF NOT EXISTS boss_damage (
      bossId INTEGER,
      userId TEXT,
      damage INTEGER DEFAULT 0,
      hits INTEGER DEFAULT 0,
      lastAttackAt INTEGER DEFAULT 0,
      PRIMARY KEY (bossId, userId)
    );

    -- Klaim item Poruv Shop (Owocash, custom role, e-wallet, item Mytic).
    -- Semua butuh aksi manual admin, jadi baris ini adalah antrean/riwayat
    -- klaim, bukan langsung tergenapi otomatis seperti item coin biasa.
    CREATE TABLE IF NOT EXISTS poruv_redemptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      guildId TEXT NOT NULL,
      itemKey TEXT NOT NULL,
      itemName TEXT NOT NULL,
      price INTEGER NOT NULL,
      detail TEXT,
      status TEXT NOT NULL DEFAULT 'pending',
      createdAt INTEGER NOT NULL,
      resolvedAt INTEGER
    );

    -- Konfigurasi per-guild. bossChannelId = channel tempat mini boss spawn
    -- untuk server itu (diatur lewat /boss-channel). betaMode = 1 kalau bot
    -- sesekali mengingatkan "masih beta, laporkan lewat /report" (diatur
    -- lewat /beta, admin). Kalau bossChannelId null, bot memakai fallback
    -- BOSS_CHANNEL_ID dari .env.
    CREATE TABLE IF NOT EXISTS guild_config (
      guildId TEXT PRIMARY KEY,
      bossChannelId TEXT,
      betaMode INTEGER DEFAULT 0,
      updatedAt INTEGER
    );

    -- Kapan tiap user boleh dikirimi pengingat mode beta berikutnya
    -- (numpang ephemeral di balasan command apa pun yang sedang dia jalankan
    -- — lihat maybeSendBetaReminder di lib/betaReminder.js). Baris dibuat
    -- pas pengingat pertama terkirim; sebelum itu user dianggap layak.
    CREATE TABLE IF NOT EXISTS beta_reminders (
      userId TEXT NOT NULL,
      guildId TEXT NOT NULL,
      nextEligibleAt INTEGER NOT NULL,
      PRIMARY KEY (userId, guildId)
    );

    -- Pemakaian /give per user per hari (kunci dayKey = YYYY-MM-DD lokal event,
    -- lewat lib/boss localDateKey). Dipakai membatasi jumlah transfer & nominal
    -- harian supaya alt/santet tidak bisa memindah coin tanpa batas. Baris baru
    -- otomatis per hari, reset alami tiap ganti hari.
    CREATE TABLE IF NOT EXISTS give_daily (
      userId TEXT,
      guildId TEXT,
      dayKey TEXT,
      count INTEGER DEFAULT 0,
      totalCoin INTEGER DEFAULT 0,
      PRIMARY KEY (userId, guildId, dayKey)
    );

    -- Daftar staff per-guild, diisi manual lewat /staff-set (bukan dari role
    -- Discord). Divisi bebas teks; deskripsi opsional.
    CREATE TABLE IF NOT EXISTS staff (
      userId TEXT,
      guildId TEXT,
      divisi TEXT NOT NULL,
      deskripsi TEXT,
      addedAt INTEGER NOT NULL,
      addedBy TEXT NOT NULL,
      PRIMARY KEY (userId, guildId)
    );

    -- Rating user ke staff. 1 user cuma boleh memberi 1 rating per staff, jadi
    -- rating ulang = update (INSERT OR REPLACE), bukan baris baru.
    CREATE TABLE IF NOT EXISTS staff_ratings (
      staffUserId TEXT,
      raterUserId TEXT,
      guildId TEXT,
      stars INTEGER NOT NULL,
      comment TEXT,
      createdAt INTEGER NOT NULL,
      updatedAt INTEGER NOT NULL,
      PRIMARY KEY (staffUserId, raterUserId, guildId)
    );

    -- Bobot urutan per DIVISI (bukan per-orang) — dipakai buat nyortir /staff
    -- (mis. Founder tampil duluan, baru Moderator, dst) alih-alih alfabetis.
    -- Diisi lewat opsi 'weight' opsional di /staff-set add; kalau satu divisi
    -- belum pernah diisi weight-nya, dianggap 0 (paling belakang).
    CREATE TABLE IF NOT EXISTS staff_divisi (
      guildId TEXT,
      divisiKey TEXT,
      weight INTEGER NOT NULL DEFAULT 0,
      updatedAt INTEGER NOT NULL,
      PRIMARY KEY (guildId, divisiKey)
    );

    -- Aktivitas per staff per bulan (kunci yearMonth YYYY-MM waktu lokal event).
    -- Baris baru per bulan = reset alami tiap ganti bulan, histori tetap ada.
    CREATE TABLE IF NOT EXISTS staff_activity (
      userId TEXT,
      guildId TEXT,
      yearMonth TEXT,
      messageCount INTEGER DEFAULT 0,
      voiceMinutes INTEGER DEFAULT 0,
      tagCount INTEGER DEFAULT 0,
      announcementCount INTEGER DEFAULT 0,
      PRIMARY KEY (userId, guildId, yearMonth)
    );

    -- Katalog kustom /poruv-shop per guild. Kosong = masih pakai default
    -- dari config/constants.js (lihat getPoruvShopItems di database/poruvShop.js).
    -- Baru terisi begitu admin mengubah katalog lewat /poruv-shop-set (ensureSeeded
    -- menyalin default ke sini dulu sebelum insert/edit/delete pertama).
    CREATE TABLE IF NOT EXISTS poruv_shop_items (
      guildId TEXT NOT NULL,
      key TEXT NOT NULL,
      name TEXT NOT NULL,
      emoji TEXT,
      price INTEGER NOT NULL,
      description TEXT DEFAULT '',
      fulfillment TEXT NOT NULL DEFAULT 'manual',
      sortOrder INTEGER NOT NULL DEFAULT 0,
      createdAt INTEGER NOT NULL,
      PRIMARY KEY (guildId, key)
    );

    -- Redeem code dibuat admin lewat /code-create. rewards disimpan sebagai
    -- JSON (array reward tervalidasi, lihat lib/redeemCodes.js parseAmountField
    -- dkk). expiresAt/maxUses null = tidak ada batas. usesCount naik tiap
    -- redeem sukses (lihat redeem_code_uses untuk mencegah redeem dobel).
    CREATE TABLE IF NOT EXISTS redeem_codes (
      code TEXT NOT NULL,
      guildId TEXT NOT NULL,
      createdBy TEXT NOT NULL,
      createdAt INTEGER NOT NULL,
      expiresAt INTEGER,
      maxUses INTEGER,
      usesCount INTEGER NOT NULL DEFAULT 0,
      rewards TEXT NOT NULL,
      PRIMARY KEY (guildId, code)
    );

    -- Riwayat siapa saja yang sudah redeem code apa, dipakai untuk
    -- mencegah satu user redeem code yang sama dua kali (lihat redeemCode
    -- di database/redeemCodes.js).
    CREATE TABLE IF NOT EXISTS redeem_code_uses (
      code TEXT NOT NULL,
      guildId TEXT NOT NULL,
      userId TEXT NOT NULL,
      redeemedAt INTEGER NOT NULL,
      PRIMARY KEY (code, guildId, userId)
    );

    CREATE INDEX IF NOT EXISTS idx_boss_active ON boss_spawns (guildId, status);
    CREATE INDEX IF NOT EXISTS idx_boss_slot ON boss_spawns (guildId, slot);
    CREATE INDEX IF NOT EXISTS idx_poruv_status ON poruv_redemptions (guildId, status);

    -- Statistik global bot, satu baris kunci-nilai. Dipakai antara lain buat
    -- hitung total command yang pernah dieksekusi (rotate status), tahan
    -- restart karena disimpan di sini, bukan variabel memori.
    CREATE TABLE IF NOT EXISTS bot_stats (
      key TEXT PRIMARY KEY,
      value INTEGER NOT NULL DEFAULT 0
    );
  `);
}

function columnExists(table, column) {
  return db
    .prepare(`PRAGMA table_info(${table})`)
    .all()
    .some(c => c.name === column);
}

function ensureColumn(table, column, definition) {
  if (!columnExists(table, column)) {
    db.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run();
  }
}

// Kolom yang ditambahkan setelah tabel awal dibuat. Database lama tidak punya
// kolom ini, jadi ditambal di sini alih-alih pakai file migrasi terpisah.
function runMigrations() {
  ensureColumn('users', 'streak', 'INTEGER DEFAULT 0');
  ensureColumn('points', 'xp', 'INTEGER DEFAULT 0');
  ensureColumn('points', 'level', 'INTEGER DEFAULT 1');
  ensureColumn('points', 'voice_seconds', 'INTEGER DEFAULT 0');
  ensureColumn('shop_items', 'effect', 'TEXT');
  // Status equip per item milik user (0/1). Equip bersifat label/carpool untuk
  // kini — efek tetap aktif lewat /use — tapi kolom ini siap untuk mekanik
  // passive bila build equip dibuat benar-benar memengaruhi buff suatu saat.
  ensureColumn('user_items', 'equipped', 'INTEGER DEFAULT 0');
  // Serangan balik boss: kapan terakhir boss mengamuk ke para penyerang.
  ensureColumn('boss_spawns', 'lastRampageAt', 'INTEGER DEFAULT 0');
  // Kunci multiplier saat quest selesai supaya buff tidak bisa ditunda klaim.
  ensureColumn('quests', 'lockedMultiplier', 'REAL DEFAULT 1');
  // Mode beta: kalau 1, bot sesekali kirim pesan pengingat "masih beta,
  // laporkan bug/saran lewat /report" ke channel. Diatur lewat /beta (admin).
  ensureColumn('guild_config', 'betaMode', 'INTEGER DEFAULT 0');
}

module.exports = { createTables, runMigrations };
