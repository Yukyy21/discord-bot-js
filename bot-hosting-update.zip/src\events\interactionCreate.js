const { MessageFlags, PermissionFlagsBits } = require('discord.js');
const { errorEmbed, warnEmbed } = require('../ui/embeds');
const logger = require('../lib/logger');
const { claimQuest, increment: incrementStat } = require('../database');
const { buildGuide } = require('../ui/guidePages');
const { buildShop } = require('../commands/economy/shop');
const { buildInventory } = require('../commands/economy/inventory');
const { buildQuest } = require('../commands/economy/quest');
const { buildLeaderboard } = require('../commands/general/leaderboard');
const { buildCredit } = require('../commands/general/credit');
const { buildStaff } = require('../commands/staff/staff');
const poruvShopCmd = require('../commands/economy/poruvShop');
const codeCreateCmd = require('../commands/admin/codeCreate');
const poruvResolveCmd = require('../commands/admin/poruvResolve');
const { renderLeaderboardCard } = require('../cards/leaderboardCard');
const { handleSeasonButton, handleSeasonArchive } = require('../ui/season');
const { handleMemberReset } = require('../ui/memberReset');
const { handleBossAutoAttack } = require('../lib/bossManager');
const { maybeSendBetaReminder } = require('../lib/betaReminder');

// Discord membatalkan token interaksi setelah beberapa detik. Slash command
// dari sebelum bot restart pasti sudah lewat batas ini, jadi dilewati saja
// daripada memancing error 10062 di log.
const STALE_COMMAND_MS = 2500;
const UNKNOWN_INTERACTION = 10062;
const ALREADY_ACKNOWLEDGED = 40060;

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (interaction.isButton()) await handleButton(interaction);
    else if (interaction.isStringSelectMenu()) await handleSelectMenu(interaction);
    else if (interaction.isModalSubmit()) await handleModalSubmit(interaction);
    else if (interaction.isChatInputCommand()) await handleCommand(interaction);
    else return;

    // Numpang di balasan interaksi apa pun (command, tombol, dropdown) yang
    // baru saja sukses dibalas — bukan pesan terpisah, jadi tidak menambah
    // notifikasi baru di luar konteks yang sedang user pakai. Dikecualikan
    // untuk tombol yang menutup/tidak melakukan apa-apa (guide_close,
    // pager_noop) — muncul pengingat pas user baru saja menutup sesuatu
    // terasa aneh. No-op diam-diam kalau syarat lain tidak terpenuhi (lihat
    // betaReminder.js).
    const skip =
      interaction.isButton?.() && ['guide_close', 'pager_noop'].includes(interaction.customId?.split(':')[0]);
    if (!skip) {
      await maybeSendBetaReminder(interaction).catch(error =>
        logger.error('Beta reminder gagal:', error.message),
      );
    }
  },
};

/**
 * State pagination disimpan di customId dengan format `aksi:a:b`, jadi tombol
 * tetap berfungsi walau bot sudah restart (tidak ada cache di memori).
 */
async function handleButton(interaction) {
  const [action, a, b, c] = interaction.customId.split(':');

  try {
    switch (action) {
      case 'members_reset':
      case 'members_confirm':
      case 'members_cancel':
        return await handleMemberReset(interaction);

      case 'season_reset':
      case 'season_confirm':
      case 'season_cancel':
      case 'season_history':
        return await handleSeasonButton(interaction);

      case 'guide_home':
        return await interaction.update(buildGuide('home'));

      case 'guide_close':
        // Pesan guide sekarang ephemeral: message.delete() tidak berlaku untuk
        // ephemeral (ditolak API Discord), jadi pakai deleteReply() lewat webhook.
        return await interaction
          .deferUpdate()
          .then(() => interaction.deleteReply())
          .catch(() => {});

      case 'pager_noop': // tombol indikator halaman, memang tidak melakukan apa-apa
        return;

      case 'shop_page': {
        // Format baru: shop_page:<tier>:<kata kunci>:<halaman> — filter ikut
        // tersimpan di customId. Tombol lama (shop_page:<halaman>) tetap jalan.
        const viewer = { userId: interaction.user.id, guildId: interaction.guildId };
        if (c === undefined) return await interaction.update(buildShop(Number(a) || 0, {}, viewer));
        return await interaction.update(buildShop(Number(c) || 0, { tier: a, query: b || '' }, viewer));
      }

      case 'inv_page': {
        // a = pemilik inventori, b = halaman
        if (a !== interaction.user.id) {
          return await interaction.reply({
            embeds: [errorEmbed('Ini inventori orang lain. Pakai `/inventory` buat lihat punyamu.')],
            flags: MessageFlags.Ephemeral,
          });
        }
        return await interaction.update(
          buildInventory(interaction.user, interaction.guildId, Number(b) || 0),
        );
      }

      case 'quest_claim': {
        // Format: quest_claim:<pemilik>:<periode>:<id quest>. Periode mengandung
        // ':' juga (daily:2026-08-23), jadi pecah dari kanan — id quest paling
        // belakang, sisanya antara pemilik dan quest adalah periode utuh.
        const parts = interaction.customId.split(':');
        if (parts[1] !== interaction.user.id) {
          return await interaction.reply({
            embeds: [errorEmbed('Ini quest orang lain. Pakai `/quest` buat lihat punyamu.')],
            flags: MessageFlags.Ephemeral,
          });
        }
        const questId = parts.pop();
        const period = parts.slice(2).join(':');
        const result = claimQuest(interaction.user.id, interaction.guildId, period, questId);
        if (!result.ok) {
          return await interaction.reply({
            embeds: [warnEmbed(result.message)],
            flags: MessageFlags.Ephemeral,
          });
        }
        // Render ulang: tombol yang sudah diklaim hilang, sisa quest tetap.
        return await interaction.update(buildQuest(interaction.user, interaction.guildId));
      }

      case 'boss_autoattack': // a = id boss di tabel boss_spawns
        return await handleBossAutoAttack(interaction, a);

      case 'lb_page': // a = kategori, b = halaman
        return await interaction.update(buildLeaderboard(a, interaction.guildId, Number(b) || 0));

      case 'credit_page': // a = halaman
        return await interaction.update(buildCredit(Number(a) || 0));

      case 'staff_page': // a = halaman
        await interaction.deferUpdate();
        return await interaction.editReply(
          await buildStaff(interaction.client, interaction.guildId, Number(a) || 0),
        );

      case 'poruv_redeem': // a = item key
        return await poruvShopCmd.handleRedeem(interaction, a);

      case 'poruv_resolve': {
        // a = redemption id
        const { resolveRedemption } = require('../database');
        // Tombol ini setara /poruv-resolve yang berizin Administrator; tanpa
        // cek ini siapa pun yang menyalin tombol bisa menyelesaikan klaim.
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
          return await interaction.reply({
            embeds: [errorEmbed('Kamu tidak punya izin menyelesaikan klaim Poruv Shop.')],
            flags: MessageFlags.Ephemeral,
          });
        }
        const result = resolveRedemption(Number(a), interaction.guildId);
        if (!result.ok) {
          return await interaction.reply({
            embeds: [errorEmbed(result.message)],
            flags: MessageFlags.Ephemeral,
          });
        }
        const r = result.row;
        logger.info(`Button resolve poruv claim #${r.id} (${r.itemName}) for <@${r.userId}>`);
        // Render ulang daftar pending tanpa klaim yang baru diselesaikan.
        const { embeds, components } = poruvResolveCmd.buildPendingList(interaction.guildId);
        return await interaction.update({ embeds, components });
      }

      default:
        return;
    }
  } catch (error) {
    if (error.code === UNKNOWN_INTERACTION || error.code === ALREADY_ACKNOWLEDGED) return;
    logger.error(`Button "${interaction.customId}" gagal:`, error);
  }
}

async function handleSelectMenu(interaction) {
  try {
    if (interaction.customId === 'guide_select') {
      return await interaction.update(buildGuide(interaction.values[0]));
    }
    if (interaction.customId.startsWith('shop_tier:')) {
      const query = interaction.customId.slice('shop_tier:'.length);
      const tier = interaction.values[0] === 'all' ? '' : interaction.values[0];
      return await interaction.update(
        buildShop(
          0,
          { tier, query },
          {
            userId: interaction.user.id,
            guildId: interaction.guildId,
          },
        ),
      );
    }
    if (interaction.customId === 'season_archive') {
      return await handleSeasonArchive(interaction);
    }
    if (interaction.customId === 'lb_filter') {
      return await renderLeaderboardCard(interaction, interaction.values[0]);
    }
    if (interaction.customId.startsWith('code_create_select:')) {
      const [, code, expiredHari, maxRedeem] = interaction.customId.split(':');
      const types = interaction.values;
      const modal = codeCreateCmd.buildRewardModal(code, expiredHari, maxRedeem, types);
      return await interaction.showModal(modal);
    }
  } catch (error) {
    if (error.code === UNKNOWN_INTERACTION || error.code === ALREADY_ACKNOWLEDGED) return;
    logger.error(`Select menu "${interaction.customId}" gagal:`, error);
  }
}

async function handleModalSubmit(interaction) {
  try {
    if (interaction.customId.startsWith('code_create_modal:')) {
      const [, code, expiredHari, maxRedeem, typesRaw] = interaction.customId.split(':');
      const types = typesRaw.split(',');
      return await codeCreateCmd.handleModalSubmit(interaction, code, expiredHari, maxRedeem, types);
    }
  } catch (error) {
    if (error.code === UNKNOWN_INTERACTION || error.code === ALREADY_ACKNOWLEDGED) return;
    logger.error(`Modal "${interaction.customId}" gagal:`, error);
  }
}

async function handleCommand(interaction) {
  if (Date.now() - interaction.createdTimestamp > STALE_COMMAND_MS) return;

  const command = interaction.client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
    incrementStat('commands_used');
  } catch (error) {
    if (error.code === UNKNOWN_INTERACTION || error.code === ALREADY_ACKNOWLEDGED) return;
    logger.error(`Command /${interaction.commandName} gagal:`, error);

    const reply = {
      embeds: [errorEmbed('Terjadi error saat menjalankan command ini.')],
      flags: MessageFlags.Ephemeral,
    };
    try {
      if (interaction.replied || interaction.deferred) await interaction.followUp(reply);
      else await interaction.reply(reply);
    } catch (replyError) {
      if (replyError.code !== ALREADY_ACKNOWLEDGED) {
        logger.error('Gagal mengirim pesan error ke user:', replyError.message);
      }
    }
  }
}
